If you are using a smaller ID spring, such as k31 or k26, use the ThinnerForK26 plunger rod.

If you are having issues with the blaster not catching when fully primed, use the TroubleshootingFix plunger rod (the catch notch is a bit further back). 

There is a version of the ThinnerForK26 plunger rod that also has this troubleshooting fix applied (the catch notch is a bit further back). 